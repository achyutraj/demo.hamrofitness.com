<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Shift extends Model
{
    use HasFactory;

    protected $fillable = ['detail_id','name','slug','from_time','to_time'];

    public function clients()
    {
        return $this->belongsToMany(GymClient::class,'gym_client_shift','shift_id','client_id');
    }
}
