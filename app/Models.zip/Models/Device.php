<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Device extends Model
{
    use HasFactory;
    protected $fillable = ['detail_id','name','code','serial_num','port_num','ip_address','device_model','device_type','device_status','vendor_name'];

    public function departments()
    {
        return $this->belongsToMany(Department::class,'department_device','device_id','department_id');
    }

    public function clients()
    {
        return $this->belongsToMany(GymClient::class,'device_gym_clients','device_id','client_id');
    }
    
}
