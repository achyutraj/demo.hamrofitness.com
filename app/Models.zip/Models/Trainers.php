<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Trainers extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'trainers';

    protected $fillable = [
        'id','name','address','email','phone'
    ];

    public function class_schedules(){
        return $this->hasMany(ClassSchedule::class,'trainer_id');
    }}
