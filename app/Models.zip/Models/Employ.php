<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Employ extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'employes';

    protected $fillable = [
        'id','first_name','middle_name','last_name','position','email','password','mobile',
        'branch_id','detail_id','date_of_birth','username','role','image','gender','merchant_id'
    ];

    public function payroll(){
        return $this->hasMany(Payroll::class,'employ_id');
    }

    public function merchant(){
        return $this->belongsTo(Merchant::class,'merchant_id');
    }

    public function getFullNameAttribute()
    {
        return ucfirst($this->first_name ). ' '. ucfirst($this->middle_name) .' '. ucfirst($this->last_name);
    }

    public function message_thread()
    {
        return $this->hasMany(MessageThread::class,'employee_id','id');
    }
}
