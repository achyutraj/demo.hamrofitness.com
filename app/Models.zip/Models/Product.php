<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Activitylog\Traits\LogsActivity;
use Spatie\Activitylog\LogOptions;

/**
 * @OA\Schema(
 *     schema="Product",
 *     title="Product",
 *     description="Product Model",
 *     @OA\Property(property="id", type="integer", example=1),
 *     @OA\Property(property="tag", type="string", example="PROD123"),
 *     @OA\Property(property="name", type="string", example="Protein Powder"),
 *     @OA\Property(property="brand_name", type="string", example="HealthFit"),
 *     @OA\Property(property="quantity", type="integer", example=100),
 *     @OA\Property(property="quantity_expired", type="integer", example=10),
 *     @OA\Property(property="quantity_damaged", type="integer", example=5),
 *     @OA\Property(property="status", type="string", example="available"),
 *     @OA\Property(property="purchase_date", type="string", format="date", example="2023-07-01"),
 *     @OA\Property(property="expire_date", type="string", format="date", example="2024-07-01"),
 * )
 */
class Product extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'id','branch_id','tag','name','brand_name','supplier','quantity','quantity_expired','quantity_damaged','status',
        'purchase_date', 'expire_date'
    ];

    protected $dates = ['purchase_date','expire_date'];

    public function getActivitylogOptions(): LogOptions
    {
        $log_name = auth()->guard('merchant')->user()->username;
        return LogOptions::defaults()
            ->useLogName($log_name);
    }

    public function suppliers() {
        return $this->belongsTo(GymSupplier::class,'supplier_id');
    }

    public function scopeExpireProductInDays($query,$businessId,$days,$limit = null){
        $start =  Carbon::today()->format('Y-m-d');
        $end =  Carbon::today()->addDays($days)->format('Y-m-d');
        return  $query->where('branch_id',$businessId)
            ->whereBetween('expire_date',[$start,$end])
            ->limit($limit)
            ->get();
    }
}
